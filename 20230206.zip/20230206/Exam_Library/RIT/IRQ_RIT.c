/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
//#include "../adc/adc.h"
#include "../led/led.h"
#include "../timer/timer.h"
#include "../../common.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
#define N 8

unsigned int VETT[N]; //Da Modificare il tipo del vettore
int currentpos;
unsigned int var1;
unsigned int var2;
unsigned int value;
volatile char alarm;
int view_mode;

unsigned int calcola_somma_prodotto(unsigned int VETT[], unsigned int M, char* alarm) ;
//timer
extern int blink1;
extern int blink2;
extern int blink3;

/*variabili per gestione debouncing dei buttons*/
volatile int down_0 = 0;
volatile int down_1 = 0;
volatile int down_2 = 0;

void init_data(){
	int i;
	var1=0;
	var2=0;
	currentpos=0;
	view_mode=0;
	value=0;
	disable_timer(0);
	reset_timer(0);
	disable_timer(1);
	reset_timer(1);
	disable_timer(2);
	reset_timer(2);
	blink1=0;
	blink2=0;
	blink3=0;
	for (i = 0 ; i < N ; i++){
		VETT[i]=0;
		}
	}

void handle_led_logic(){
	if(var1<=15 && var2<=15)
					LED_Out_Akimbo(var1,var2);
	else if(var1<=15 && var2>15){
		LED_Out(var1 << 4);
		enable_timer(1);
	}
	else if(var1>15 && var2<=15){
		LED_Out(var2);
		enable_timer(0);
	}
	else{
		enable_timer(0);
		enable_timer(1);
	}
}

void view_mode_handling(){
	char tmp;
	unsigned int tmpres=value;
	view_mode=1;
	tmp=alarm;
	if(tmp==0xFF){
		LED_Out(tmpres);
	}
	else{
		enable_timer(2);		
	}
}



void RIT_IRQHandler (void)
{		
	
	/*GESTIONE ADC*/
	//ADC_start_conversion();
	
	static int j_select=0, j_left=0, j_right=0, j_down=0, j_up=0;
	
	/*Gestione Joystick Polling*/
	if((LPC_GPIO1->FIOPIN & (1<<25)) == 0){ //joystick select
		j_select++;
		switch(j_select){
			case 1:
				break;
			//per controllare pressioni prolungate: es. 5[sec]/50[msec](RIT timer) = 100
			//case 100:
			//	break;
			default:
				break;
		}
	}else
		j_select=0;
	
	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){ //joystick down
		j_down++;
		switch(j_down){
			case 1:
				if(view_mode==0){
				VETT[currentpos]=var1;
				currentpos++;
			  VETT[currentpos]=var2;
				currentpos++;
				if(currentpos==N){
				value=calcola_somma_prodotto(VETT,currentpos,&alarm);
				view_mode_handling();
				}
			}
				break;			
			default:
				break;
		}
	}else
		j_down=0;
	
	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){ //joystick left
		j_left++;
		switch(j_left){
			case 1:
				if(view_mode==0){
				var2++;
			 handle_led_logic();
				}
				break;			
			default:
				break;
		}
	}else
		j_left=0;
	
	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){ //joystick right
		j_right++;
		switch(j_right){
			case 1:
				break;			
			default:
				break;
		}
	}else
		j_right=0;
	
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){ //joystick up
		j_up++;
		switch(j_up){
			case 1:
				if(view_mode==0){
				var2++;
			   handle_led_logic();
				}
				break;			
			default:
				break;
		}
	}else
		j_up=0;
	
	/*Gestione BUTTONS*/
	if(down_0!=0){  
			down_0 ++;  
			//controllo il piedino fisico 10->INT0, 11->KEY1, 12->KEY2
			if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){ 
				switch(down_0){
				case 2:
					//codice da eseguire in caso di pressione del button
					break;
				//per controllare pressioni prolungate: es. 5[sec]/50[msec](RIT timer) = 100
				//case 100:
				//	break;
				default:
					//se voglio gestire il button on X click
					//if(down_0 % X == 0){
					//}					
					break;
			}
		}
		else {	/* button released */
			//al rilascio del bottone il valore di down*valore inizializzazione RIT (50ms di solito) indica per quanti ms � stato premuto il pulsante
			down_0=0;			
			NVIC_EnableIRQ(EINT0_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
		}
	}
	
	if(down_1!=0){  
			down_1 ++;  
			//controllo il piedino fisico 10->INT0, 11->KEY1, 12->KEY2
			if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){ 
				switch(down_1){
				case 2:
					if(view_mode==1){
						view_mode=0;
						disable_timer(2);
						reset_timer(2);
						init_data();
					}
					break;				
				default:
					//se voglio gestire il button on X click
					//if(down_1 % X == 0){
					//}					
					break;
			}
		}
		else {	/* button released */
			//al rilascio del bottone il valore di down*valore inizializzazione RIT (50ms di solito) indica per quanti ms � stato premuto il pulsante
			if(down_1*50<2000){
				var1=var1+2;
				handle_led_logic();
				
			}
			else if(down_1*50>=2000 && down_1*50<=3000){
				var1+=3;
				handle_led_logic();
			}
			else{
				value=calcola_somma_prodotto(VETT,currentpos,&alarm);
				view_mode_handling();
			}
			down_1=0;			
			NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
	
	if(down_2!=0){  
			down_2 ++;  
			//controllo il piedino fisico 10->INT0, 11->KEY1, 12->KEY2
			if((LPC_GPIO2->FIOPIN & (1<<12)) == 0){ 
				switch(down_2){
				case 2:
					//codice da eseguire in caso di pressione del button
					break;				
				default:
					//se voglio gestire il button on X click
					//if(down_2 % X == 0){
					//}					
					break;
			}
		}
		else {	/* button released */
			//al rilascio del bottone il valore di down*valore inizializzazione RIT (50ms di solito) indica per quanti ms � stato premuto il pulsante
			down_2=0;			
			NVIC_EnableIRQ(EINT2_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 24);     /* External interrupt 0 pin selection */
		}
	}
	
	
	reset_RIT();
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
