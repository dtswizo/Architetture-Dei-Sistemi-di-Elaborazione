/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
//#include "../adc/adc.h"
#include "../led/led.h"
#include "../timer/timer.h"
#include "../../common.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
#define N 4


/*variabili per gestione debouncing dei buttons*/
volatile int down_0 = 0;
volatile int down_1 = 0;
volatile int down_2 = 0;
unsigned int VETT[N]; 
int size;
 unsigned var;
int key1_pressed=0;
extern unsigned int led_final_value;
extern unsigned int led_07_reverse;
int cnt=0;
extern unsigned char contatore_inrange(unsigned int VETT[], const unsigned int M);
unsigned char res;
extern int tasti_disabilitati;

void update_array_handling(){
	if(size<N){
		VETT[size]=var;
		size++;
	}
	else{
		LED_Out(0);
		disable_timer(1);
		tasti_disabilitati=1;
		res=contatore_inrange(VETT,N);
		LED_Out(res);
		enable_timer(3);
		disable_timer(2);
	}
}

void full_flush(){
	int i;
	size=0;
	tasti_disabilitati=0;
	var=0;
	key1_pressed=0;
	cnt=0;
	led_final_value=0;
	led_07_reverse=0;
	res=0;
	
	for(i=0; i < N ; i++){
		VETT[i]=0;
	}
}



void RIT_IRQHandler (void)
{		
	
	/*GESTIONE ADC*/
	//ADC_start_conversion();
	
	static int j_select=0, j_left=0, j_right=0, j_down=0, j_up=0;
	
	/*Gestione Joystick Polling*/
	if((LPC_GPIO1->FIOPIN & (1<<25)) == 0){ //joystick select
		j_select++;
		switch(j_select){
			case 1:
				break;
			//per controllare pressioni prolungate: es. 5[sec]/50[msec](RIT timer) = 100
			//case 100:
			//	break;
			default:
				break;
		}
	}else
		j_select=0;
	
	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){ //joystick down
		j_down++;
		switch(j_down){
			case 1:
				break;			
			default:
				break;
		}
	}else
		j_down=0;
	
	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){ //joystick left
		j_left++;
		switch(j_left){
			case 1:
				break;			
			default:
				break;
		}
	}else
		j_left=0;
	
	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){ //joystick right
		j_right++;
		switch(j_right){
			case 1:
				break;			
			default:
				break;
		}
	}else
		j_right=0;
	
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){ //joystick up
		j_up++;
		switch(j_up){
			case 1:
				break;			
			default:
				break;
		}
	}else
		j_up=0;
	
	/*Gestione BUTTONS*/
	if(down_0!=0){  
			down_0 ++;  
			//controllo il piedino fisico 10->INT0, 11->KEY1, 12->KEY2
			if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){ 
				switch(down_0){
				case 2:
					//codice da eseguire in caso di pressione del button
					break;
				//per controllare pressioni prolungate: es. 5[sec]/50[msec](RIT timer) = 100
				//case 100:
				//	break;
				default:
					//se voglio gestire il button on X click
					//if(down_0 % X == 0){
					//}					
					break;
			}
		}
		else {	/* button released */
			down_0=0;			
			NVIC_EnableIRQ(EINT0_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
		}
	}
	
	if(down_1!=0){  
			down_1 ++;  
			//controllo il piedino fisico 10->INT0, 11->KEY1, 12->KEY2
			if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){ 
				switch(down_1){
				case 2:
					if(tasti_disabilitati==0){
					key1_pressed=1;
					enable_timer(0);
					}
					break;				
				default:
					//se voglio gestire il button on X click
					//if(down_1 % X == 0){
					//}					
					break;
			}
		}
		else {	/* button released */
			down_1=0;			
			NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	}
	
	if(down_2!=0){  
		  unsigned int tmp1; 
			unsigned int tmp2; 
		  unsigned int tmp3;
	    unsigned int tmp4;
		  unsigned int tmp5;
	    unsigned int tmp6;
			down_2 ++;  
			//controllo il piedino fisico 10->INT0, 11->KEY1, 12->KEY2
			if((LPC_GPIO2->FIOPIN & (1<<12)) == 0){ 
				switch(down_2){
				case 2:
					if(key1_pressed && tasti_disabilitati==0){
						cnt++;
						if(cnt==1){
							enable_timer(2);
							size=0;
							var=0;
						}
						var= (LPC_TIM0->TC)/((25000000)/100); //tempo in centesimi di secondo
						tmp1= (var & 0xFF000000);
						tmp2= (var & 0x00FF0000);
						tmp3= (tmp1 | tmp2);
						tmp4= (var & 0x0000FF00);
						tmp5= (var & 0x000000FF);
						tmp6= (tmp4 & tmp5);
						led_final_value= tmp3^tmp5; //XOR
						tmp5=~tmp5; //NOT
						led_07_reverse=tmp5;
						enable_timer(1);
					  disable_timer(0);
						reset_timer(0);
						key1_pressed=0;
					}
					break;				
				default:
					//se voglio gestire il button on X click
					//if(down_2 % X == 0){
					//}					
					break;
			}
		}
		else {	/* button released */
			down_2=0;			
			NVIC_EnableIRQ(EINT2_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 24);     /* External interrupt 0 pin selection */
		}
	}
	
	
	reset_RIT();
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
