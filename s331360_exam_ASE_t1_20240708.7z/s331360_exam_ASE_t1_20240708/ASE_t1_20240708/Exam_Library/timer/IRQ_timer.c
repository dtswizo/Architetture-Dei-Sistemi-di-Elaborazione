/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "timer.h"
#include "../led/led.h"
#include "../RIT/RIT.h"
#include "../../common.h"

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
#define N 4
int blink1=0;
int blink2=0;
int timer_scaduto=0;
extern unsigned char RES[N];
extern int currentpos_res;

/*
///blinking///
if(blink%2==0){
 LED_Out(255);
 blink++;
}
else{
 LED_Out(0);
 blink++;
 if(blink==X){
  disable_timer(TimerUsato);
	reset_timer(TimerUsato);
	blink=0;
 }
}
*/
 



void TIMER0_IRQHandler (void)
{
	timer_scaduto=1;
	disable_timer(0);
	reset_timer(0);
	LPC_TIM0->IR = 1;
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
	if(blink1%2==0){
 LED_Out(RES[currentpos_res]);
 blink1++;
}
	else{
	 LED_Out(0);
	 blink1++;
	 if(blink1==10){ //questo valore dovrebbe essere 6 
		disable_timer(1);
		reset_timer(1);
		blink1=0;
		 currentpos_res++;
		 if(currentpos_res==N){
			 init_data();
		 }
		 else{
			 handle_res();
		 }
	 }
	}
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer2_IRQHandler
**
** Descriptions:		Timer/Counter 2 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER2_IRQHandler (void)
{
	if(blink2%2==0){
 LED_Out(RES[currentpos_res]);
 blink2++;
}
	else{
	 LED_Out(0);
	 blink2++;
	 if(blink2==10){
		disable_timer(2);
		reset_timer(2);
		blink2=0;
		 currentpos_res++;
		 if(currentpos_res==N){
			 init_data();
		 }
		 else{
			 handle_res();
		 }
	 }
	}
	
  LPC_TIM2->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer3_IRQHandler
**
** Descriptions:		Timer/Counter 3 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER3_IRQHandler (void)
{
  LPC_TIM3->IR = 1;			/* clear interrupt flag */
  return;
}





/******************************************************************************
**                            End Of File
******************************************************************************/
